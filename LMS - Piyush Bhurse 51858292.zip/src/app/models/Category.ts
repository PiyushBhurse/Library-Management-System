export class Category {
    lable: string;
    value: string;
    desc:string;
}